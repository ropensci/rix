utils::globalVariables(c("outcome"))
