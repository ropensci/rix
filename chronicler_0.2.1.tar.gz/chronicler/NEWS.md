# chronicler

# chronicler 0.2.1

## Maintenance release

* Compatibility with dplyr 1.1.0
* Changed link to canonical link in the Readme.md

# chronicler 0.2.0

## New features

* First CRAN release
